%% Joshua Oates - a_215 - HW 3 - COEs 

clear all;
close all;
clc;

% 𝑅⃗ = -2315.9 𝐼̂ + 2168.6 𝐽̂ + 6314.5 𝐾̂ [𝑘𝑚]
% 𝑉⃗ = -3.0599𝐼̂  6.0645 𝐽̂ -3.2044 𝐾̂ [𝑘𝑚/𝑠]

R = [-2315.9 , 2168.6 , 6314.5];
V = [-3.0599 , 6.0645 , -3.2044];



% Write a MATLAB function to calculate the classical orbital 
% elements from any state vector (R and V pair) of a spacecraft in an orbit
% around Earth. The function should have 𝑅⃗ and 𝑉⃗ as inputs (expressed in the
% ECI frame) and output semi-major axis (𝑎), eccentricity (𝑒), true anomaly
% (nu), inclination (𝑖), RAAN (Ω), and argument of perigee (𝜔).

%% Part 4
% Write a script to call your function with the 𝑅⃗ and 𝑉⃗ vectors 
% from above as inputs. The script should print all six COE’s (with units) 
% neatly to the Command Window.

[a,e,nu,i,raan,aop,T] = COEsOatesJoshua(R,V);

disp("Semi-major axis       : " + a + " km")
disp("eccentricity          : " + e + " km")
disp("true anomaly          : " + nu + " degrees")
disp("inclination           : " + i + " degrees")
disp("RAAN                  : " + raan + " degrees")
disp("Argument of periapsis : " + aop + " degrees")
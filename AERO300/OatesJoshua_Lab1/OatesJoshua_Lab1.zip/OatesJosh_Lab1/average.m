function ave = average(x)
    ave = sum(x(:))/numel(x); 
end